"""Resource-only UTF-8 process manifest patch for unsigned TSK console executables.
Official code bytes are unchanged. Windows 10 1903+ is required for UTF-8 ACP.
"""
from pathlib import Path
import ctypes
from ctypes import wintypes
import hashlib
import json
import xml.etree.ElementTree as ET

root = Path(__file__).parent
binary_dir = root / "vendor" / "sleuthkit-4.15.0-win32" / "bin"
k = ctypes.WinDLL("kernel32", use_last_error=True)
k.LoadLibraryExW.argtypes = (wintypes.LPCWSTR, wintypes.HANDLE, wintypes.DWORD)
k.LoadLibraryExW.restype = wintypes.HMODULE
k.FindResourceW.argtypes = (wintypes.HMODULE, wintypes.LPCWSTR, wintypes.LPCWSTR)
k.FindResourceW.restype = wintypes.HANDLE
k.LoadResource.argtypes = (wintypes.HMODULE, wintypes.HANDLE)
k.LoadResource.restype = wintypes.HANDLE
k.LockResource.argtypes = (wintypes.HANDLE,)
k.LockResource.restype = wintypes.LPVOID
k.SizeofResource.argtypes = (wintypes.HMODULE, wintypes.HANDLE)
k.SizeofResource.restype = wintypes.DWORD
k.FreeLibrary.argtypes = (wintypes.HMODULE,)
k.BeginUpdateResourceW.argtypes = (wintypes.LPCWSTR,wintypes.BOOL)
k.BeginUpdateResourceW.restype = wintypes.HANDLE
k.UpdateResourceW.argtypes = (wintypes.HANDLE,wintypes.LPCWSTR,wintypes.LPCWSTR,wintypes.WORD,wintypes.LPVOID,wintypes.DWORD)
k.UpdateResourceW.restype = wintypes.BOOL
k.EndUpdateResourceW.argtypes = (wintypes.HANDLE,wintypes.BOOL)
k.EndUpdateResourceW.restype = wintypes.BOOL
resource_type = ctypes.cast(ctypes.c_void_p(24), wintypes.LPCWSTR)
resource_name = ctypes.cast(ctypes.c_void_p(1), wintypes.LPCWSTR)
records = []
for name in ("fls", "fsstat", "mmls", "icat"):
    path = binary_dir / (name + ".exe")
    before = hashlib.sha256(path.read_bytes()).hexdigest()
    handle = k.LoadLibraryExW(str(path),None,2)
    if not handle: raise ctypes.WinError(ctypes.get_last_error())
    resource = k.FindResourceW(handle,resource_name,resource_type)
    if not resource: raise ctypes.WinError(ctypes.get_last_error())
    length = k.SizeofResource(handle,resource)
    blob = k.LockResource(k.LoadResource(handle,resource))
    manifest = ctypes.string_at(blob,length).decode("utf-8-sig").rstrip("\0")
    k.FreeLibrary(handle)
    (root / (name + ".original.manifest")).write_text(manifest,encoding="utf-8")
    if 'activeCodePage' in manifest:
        raise RuntimeError("Already patched: " + name)
    addition = '<application xmlns="urn:schemas-microsoft-com:asm.v3"><windowsSettings><activeCodePage xmlns="http://schemas.microsoft.com/SMI/2019/WindowsSettings">UTF-8</activeCodePage></windowsSettings></application>'
    manifest = manifest.replace('</assembly>',addition+'</assembly>')
    ET.fromstring(manifest)
    encoded = manifest.encode("utf-8")
    update=k.BeginUpdateResourceW(str(path),False)
    if not update: raise ctypes.WinError(ctypes.get_last_error())
    buffer=ctypes.create_string_buffer(encoded)
    if not k.UpdateResourceW(update,resource_type,resource_name,1033,buffer,len(encoded)):
        k.EndUpdateResourceW(update,True)
        raise ctypes.WinError(ctypes.get_last_error())
    if not k.EndUpdateResourceW(update,False): raise ctypes.WinError(ctypes.get_last_error())
    records.append({"name":path.name,"original_sha256":before,"patched_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"patch":"Embedded RT_MANIFEST activeCodePage=UTF-8; no executable code changed"})
(root / "utf8-manifest-patches.json").write_text(json.dumps(records,indent=2),encoding="utf-8")
print(json.dumps(records,indent=2))
